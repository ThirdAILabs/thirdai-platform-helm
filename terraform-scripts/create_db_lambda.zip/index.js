const { Client } = require('pg');

exports.handler = async (event) => {
  const dbConfig = {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  };
  
  const client = new Client(dbConfig);
  
  try {
    await client.connect();
    const databasesToCreate = event.create_dbs || [];
    
    for (const dbName of databasesToCreate) {
      console.log(`Creating database: ${dbName}`);
      await client.query(`CREATE DATABASE ${dbName};`);
    }
    
    return {
      statusCode: 200,
      body: `Successfully created databases: ${databasesToCreate.join(', ')}`
    };
  } catch (error) {
    console.error('Error creating databases:', error);
    throw error;
  } finally {
    await client.end();
  }
};